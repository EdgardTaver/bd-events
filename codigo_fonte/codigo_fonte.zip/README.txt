Nome                           | Nr. USP
-------------------------------|---------
Edgard van Tol Taver           | 10686575
Guilherme Vaz de Sousa Ribeiro | 10300320
Pedro Raul Taborga da Costa    | 4537076